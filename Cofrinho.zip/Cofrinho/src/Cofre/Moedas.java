package Cofre;

public abstract class Moedas {
    protected double valor; // Valor da moeda (Protegido)
    protected String pais; // País da moeda

    public Moedas(double valor, String pais) {
        this.valor = valor;
        this.pais = pais;
    }

    public double getValor() {
        return valor;
    }

    public String getPais() {
        return pais;
    }

    public double converterParaReal() {
        return valor; // Retornará o valor da moeda (não fará conversão)
    }
}