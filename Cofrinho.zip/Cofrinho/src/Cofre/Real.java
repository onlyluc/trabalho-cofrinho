package Cofre;

public class Real extends Moedas {
    public Real(double valor) {
        super(valor, "Real");
    }

    @Override
    public double converterParaReal() {
        return getValor();
    }
}