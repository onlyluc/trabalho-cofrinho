package Cofre;

public class Dolar extends Moedas {
    public Dolar(double valor) {
        super(valor, "Dolar");
    }

    @Override
    public double converterParaReal() {
        
        return getValor() * 5.42; //Valor atual do dolar 09/07/2024
    }
}