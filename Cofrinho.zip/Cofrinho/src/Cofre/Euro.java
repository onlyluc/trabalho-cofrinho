package Cofre;
public class Euro extends Moedas {
    public Euro(double valor) {
        super(valor, "Euro");
    }

    @Override
    public double converterParaReal() {
        
        return getValor() * 5.86; // Valor atual do Euro 09/07/2024
    }
}